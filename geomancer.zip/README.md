# Geomancer

This is tool originally made for generating volumes for use in the Pistol Mix editor from .png images, but the focus has shifted to make other changes to the map files easier. More functions are coming in later versions.

Detailed usage guide can be found here: https://mod.io/g/pistol-whip/r/geomancer

---

This tool is provided as is. Use at your own risk, though there isn't any, really. If you need help, shoot me a message and I might help you out, but keep in mind the tool is still very early in development, so issues are expected.

Made with Defold, using extensions by Björn Ritzl, Sven Andersson and Sergey Lerg. 

---

This project is licensed under the terms of the
DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE, version 3,
as published by theiostream on March 2012, as it follows:

0. You just DO WHAT THE FUCK YOU WANT TO.
